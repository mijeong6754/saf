﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantDB
{
    partial class Reservation
    {
        public string StoreName { get; set; }
    }
}
