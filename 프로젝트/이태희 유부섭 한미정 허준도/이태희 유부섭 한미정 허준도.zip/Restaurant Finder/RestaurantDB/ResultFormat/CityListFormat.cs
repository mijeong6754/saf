﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantDB.ResultFormat
{
    public class CityListFormat
    {
        public string Name { get; set; }
        public int CityId { get; set; }
    }
}
