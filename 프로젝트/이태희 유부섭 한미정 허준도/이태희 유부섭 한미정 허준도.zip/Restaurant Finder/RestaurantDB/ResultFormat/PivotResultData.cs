﻿using RestaurantDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantDB
{
    class PivotResultData
    {
        public City cities { get; set; }
        public int MyProperty { get; set; }
    }
}
