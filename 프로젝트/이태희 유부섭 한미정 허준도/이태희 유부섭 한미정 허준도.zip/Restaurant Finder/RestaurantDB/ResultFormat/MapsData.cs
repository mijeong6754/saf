﻿using System.Drawing;

namespace RestaurantDB
{
    public class MapsData
    {
        public string Name { get; set; }
        public Bitmap Image { get; set; }
    }
}